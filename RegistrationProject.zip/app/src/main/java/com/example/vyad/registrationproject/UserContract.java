package com.example.vyad.registrationproject;

import android.net.Uri;
import android.provider.BaseColumns;

public class UserContract {

    // Content authority unique for each application
    private static final String CONTENT_AUTHORITY = "com.example.vyad.registrationproject";

    //   base content uri to be used by content resolver to access our content provider
    private static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    /**
     * Class holds the schema of table and attribute of database.
     */
    public static final class UserEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .build();

        public static final String TABLE_NAME = "user";

        public static final String EMAIL_ID = "email_id";

        public static final String NAME = "name";

        public static final String PASSWORD = "password";

        public static final String PHONE = "phone";
    }
}
