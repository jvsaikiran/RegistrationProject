package com.example.vyad.registrationproject;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.util.Patterns;


import static com.example.vyad.registrationproject.UserContract.UserEntry.CONTENT_URI;

public class LoginActivity extends AppCompatActivity {
    private EditText nameView;
    private EditText emailView;
    private EditText passwordView;
    private EditText phoneView;

    private Button signinButton;
    private Button createButton;

    private Toast toast;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        nameView = findViewById(R.id.name_textview);
        emailView = findViewById(R.id.email_textview);
        passwordView = findViewById(R.id.password_textview);
        phoneView = findViewById(R.id.phone_textview);

        signinButton = findViewById(R.id.sigin_button);
        createButton = findViewById(R.id.create_button);
    }

    public void onCreateButtonClick(View view) {
        String name = String.valueOf(nameView.getText());
        String email = String.valueOf(emailView.getText());
        String password = String.valueOf(passwordView.getText());
        String phone = String.valueOf(phoneView.getText());

        int phone_no = Integer.parseInt(phone);

//        TODO 1: validate user input

        //Check  Validity of email, password an=
        if (! isValidEmail(email)){
            Toast.makeText(this, "InValid Email ID", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(! isValidPassword(password) ){
            Toast.makeText(this, "InValid password", Toast.LENGTH_SHORT).show();
            return;
        }
        else if ( phone_no >= Math.pow(10,10) || phone_no < Math.pow(10,9) ){
            Toast.makeText(this, "InValid phone number", Toast.LENGTH_SHORT).show();
            return;
        }
        //insert the Data

            ContentResolver contentResolver = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(UserContract.UserEntry.EMAIL_ID, email);
            cv.put(UserContract.UserEntry.NAME, name);
            cv.put(UserContract.UserEntry.PASSWORD, password);
            cv.put(UserContract.UserEntry.PHONE, phone);
            contentResolver.insert(CONTENT_URI, cv);

            Toast.makeText(this, "Successfully created account", Toast.LENGTH_LONG).show();
    }

    //Method to validate password strength
    public boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;

        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[,.@#$%^&+=_])(?=\\S+$).{4,}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }

    //Method to validate Email ID
    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    public void onLogInLabelClick(View view) {
        emailView.setVisibility(View.VISIBLE);
        passwordView.setVisibility(View.VISIBLE);
        signinButton.setVisibility(View.VISIBLE);
        nameView.setVisibility(View.GONE);
        phoneView.setVisibility(View.GONE);
        createButton.setVisibility(View.GONE);
    }

    public void onSignUpLabelClick(View view) {
        emailView.setVisibility(View.VISIBLE);
        passwordView.setVisibility(View.VISIBLE);
        signinButton.setVisibility(View.GONE);
        nameView.setVisibility(View.VISIBLE);
        phoneView.setVisibility(View.VISIBLE);
        createButton.setVisibility(View.VISIBLE);
    }

    public void onLogInClick(View view) {
        String email = String.valueOf(emailView.getText());
        String password = String.valueOf(passwordView.getText());

        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(CONTENT_URI, null, null, null,null);

        if (cursor == null || cursor.getCount() == 0) {
            //showErrorMessage(email);
            return;
        }

        while(cursor.moveToNext()) {
            String storedEmail = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.EMAIL_ID));
            String storedPassword = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.PASSWORD));

            if (TextUtils.equals(email, storedEmail) && TextUtils.equals(password, storedPassword)) {
                String name = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.NAME));
                String phone = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.PHONE));

                Intent intent = new Intent(this, WelcomeActivity.class);
                intent.putExtra("Name", name);
                intent.putExtra("Email", email);
                intent.putExtra("Phone", phone);
                startActivity(intent);
                break;
            }
            else {
                showErrorMessage(email);
            }
        }

    }

    private void showErrorMessage(final String email) {
        if (toast != null) {
            toast.cancel();
        }
        toast = Toast.makeText(this, "Ivalid Email or Password ", Toast.LENGTH_LONG);
        toast.show();
    }
}
