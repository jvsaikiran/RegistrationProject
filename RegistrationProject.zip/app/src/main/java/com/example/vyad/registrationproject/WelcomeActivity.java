package com.example.vyad.registrationproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Intent intent = getIntent();

        String name = intent.getStringExtra("Name");
        String email = intent.getStringExtra("Email");
        String phone = intent.getStringExtra("Phone");

        TextView nameView = findViewById(R.id.name_textview);
        TextView emailView = findViewById(R.id.email_textview);
        TextView phoneView = findViewById(R.id.phone_textview);

        nameView.setText(name);
        emailView.setText(email);
        phoneView.setText(phone);
    }
}
